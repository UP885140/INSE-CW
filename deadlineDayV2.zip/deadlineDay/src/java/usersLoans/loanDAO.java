/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usersLoans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import userAccount.DDuser;

/**
 *
 * @author Jack
 */
public class loanDAO {
    
    public int registerLoan(Loan loan) throws ClassNotFoundException {
        String INSERT_LOAN_SQL = "INSERT INTO DDLOAN" +
            "  (loan_id, book_name, author, loanday, loanperiod, user_id) VALUES " +
            " (?, ?, ?, ?, ?,?);";

        int result = 0;

        Class.forName("org.apache.derby.jdbc.ClientDriver");

        try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/sample?useSSL=false", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_LOAN_SQL)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, loan.getBookname());
            preparedStatement.setString(3, loan.getAuthor());
            preparedStatement.setString(4, loan.getLoanday());
            preparedStatement.setString(5, loan.getLoanperiod());
            
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
        return result;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
    
}
