/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userAccount;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Jack
 */
public class DDuserDAO {
    
    public int registerUser(DDuser user) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO DDUSER" +
            "  (user_id, first_name, last_name, email, password) VALUES " +
            " (?, ?, ?, ?, ?);";

        int result = 0;

        Class.forName("org.apache.derby.jdbc.ClientDriver");

        try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/sample?useSSL=false", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, user.getFirstname());
            preparedStatement.setString(3, user.getLastname());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setString(5, user.getPassword());
            
           
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
        return result;
    }
    
    public boolean validateLogin(DDuserLogin login) throws ClassNotFoundException {
        boolean status = false;

        Class.forName("org.apache.derby.jdbc.ClientDriver");

        try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/sample?useSSL=false", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM login WHERE email = ? AND password = ? ")) {
            preparedStatement.setString(1, login.getEmail());
            preparedStatement.setString(2, login.getPassword());

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();

        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }
    

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
    
}
